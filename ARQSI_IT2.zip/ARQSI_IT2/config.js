module.exports = {
    'secret': 'wowSoSecret',
    'database': "mongodb://client:qwerty@ds042417.mlab.com:42417/arqsi20172018",
    'IT1': 'http://arqsiit1.azurewebsites.net/api/',
    'smtp2User': "arqsiIT2",
    'smtp2Passwd': "Qwerty123!"
};